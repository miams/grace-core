#!/usr/bin/python
# -*- coding: utf-8 -*-
#Lambda code to download IOC and upload to S3. Also updates and rotates guardDuty ThreatList.

import boto3
import logging
import json
import hashlib
import hmac
import httplib
import urllib
import time
import traceback
import email
from botocore.vendored import requests
from datetime import datetime
from os import environ

def lambda_handler(event, context):

    print ("Lambda Triggered")

    #------------------------------------------------------------------
    # Set Log Level
    #------------------------------------------------------------------
    global log_level
    log_level = str(environ['LOG_LEVEL'].upper())
    if log_level not in ['DEBUG', 'INFO','WARNING', 'ERROR','CRITICAL']:
        log_level = 'ERROR'
    logging.getLogger().setLevel(log_level)

    #------------------------------------------------------------------
    # Set query parameters
    #------------------------------------------------------------------
    print ("Making Query")
    queryType = '/view/iocs?'
    query = {
        'startDate' : int(time.time()) - (int(environ['DAYS_REQUESTED'])*86400),
        'endDate' : int(time.time())
    }

    #------------------------------------------------------------------
    # Query 3rd Party service
    #------------------------------------------------------------------
    #Create Query
    enc_q = queryType + urllib.urlencode(query) + '&format=csv'

    #Generate proper accept_header for requested indicator type
    accept_header = 'text/csv'

    #Generate Hash for Auth
    timeStamp = email.Utils.formatdate(localtime=True)
    data = enc_q + '2.6' + accept_header + unicode(timeStamp)
    hashed = hmac.new(environ['PRIVATE_KEY'], data, hashlib.sha256)

    headers = {
        'Accept': accept_header,
        'Accept-Version': '2.6',
        'X-Auth': environ['PUBLIC_KEY'],
        'X-Auth-Hash': hashed.hexdigest(),
        'X-App-Name': 'mysight-api',
        'Date': timeStamp
    }

    #Get dataset
    print ("About to make api call")
    conn = httplib.HTTPSConnection('api.isightpartners.com')
    conn.request('GET', enc_q, '', headers)
    response = conn.getresponse()
    result = {
        'statusCode': str(response.status),
        'body':  {'message': str(response.reason)}
    }
    print (response)
    print(result)

    #------------------------------------------------------------------
    # Read Content
    #------------------------------------------------------------------
    timeStamp = datetime.now()
    print ("File Downloaded")
    fileName = "/tmp/iSIGHT_%s_%s_days.csv"%(timeStamp.strftime("%Y%m%d-%H%M%S"), environ['DAYS_REQUESTED'])
    with open(fileName, 'wb') as f:
        f.write(response.read())
        f.close()

    #------------------------------------------------------------------
    # Upload to S3
    #------------------------------------------------------------------
    print ("File Uoloading to S3")
    s3 = boto3.client('s3')
    outputFileName = "guardduty/iSIGHT/%s_%s_days.csv"%(timeStamp.strftime("%Y%m%d-%H%M%S"), environ['DAYS_REQUESTED'])
    s3.upload_file(fileName, environ['OUTPUT_BUCKET'], outputFileName, ExtraArgs={'ContentType': "application/CSV"})

    #------------------------------------------------------------------
    # Guard Duty
    #------------------------------------------------------------------
    location = "https://s3.amazonaws.com/%s/%s"%(environ['OUTPUT_BUCKET'], outputFileName)
    name = "TF-%s"%timeStamp.strftime("%Y%m%d")
    guardduty = boto3.client('guardduty')
    response = guardduty.list_detectors()
    detectorId = response['DetectorIds'][0]
    print ("Updating GuardDuty threatList")

    try:
        response = guardduty.create_threat_intel_set(
            Activate=True,
            DetectorId=detectorId,
            Format='FIRE_EYE',
            Location=location,
            Name=name
        )

    except Exception as error:
        if "name already exists" in error.message:
            found = False
            response = guardduty.list_threat_intel_sets(DetectorId=detectorId)
            for setId in response['ThreatIntelSetIds']:
                response = guardduty.get_threat_intel_set(DetectorId=detectorId, ThreatIntelSetId=setId)
                if (name == response['Name']):
                    found = True
                    response = guardduty.update_threat_intel_set(
                        Activate=True,
                        DetectorId=detectorId,
                        Location=location,
                        Name=name,
                        ThreatIntelSetId=setId
                    )
                    break

            if not found:
                raise

        elif "AWS account limits" in error.message:
            #--------------------------------------------------------------
            # Limit reached. Try to rotate the oldest one
            #--------------------------------------------------------------
            oldestDate = None
            oldestID = None
            response = guardduty.list_threat_intel_sets(DetectorId=detectorId)
            for setId in response['ThreatIntelSetIds']:
                response = guardduty.get_threat_intel_set(DetectorId=detectorId, ThreatIntelSetId=setId)
                tmpName = response['Name']

                if tmpName.startswith('TF-'):
                    setDate = datetime.strptime(tmpName.split('-')[-1], "%Y%m%d")
                    if oldestDate == None or setDate < oldestDate:
                        oldestDate = setDate
                        oldestID = setId

            if oldestID != None:
                response = guardduty.update_threat_intel_set(
                    Activate=True,
                    DetectorId=detectorId,
                    Location=location,
                    Name=name,
                    ThreatIntelSetId=oldestID
                )
            else:
                raise

        else:
            raise

            #------------------------------------------------------------------
        # Update result data
         #------------------------------------------------------------------
        result = {
            'statusCode': '200',
            'body':  {'message': "You requested: %s day(s) of /view/iocs indicators in CSV"%environ['DAYS_REQUESTED']}
        }

    except Exception as error:
        result = {
            'statusCode': '500',
            'body':  {'message': error.message}
        }

    #------------------------------------------------------------------
    # Send Result
    #------------------------------------------------------------------
    if 'ResponseURL' in event:
        send_response(event, context, responseStatus, responseData)

    return json.dumps(result)
